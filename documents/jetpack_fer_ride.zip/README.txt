Za pokretanje aplikacije potrebno je dva puta kliknuti na datoteku Jetpack_FERride.jar. 
Ako to ne radi u terminalu se pozicionirajte u ovaj direktorij i izvršite naredbu 
	
	java -jar Jetpack_FERride.jar

Za ispravan rad aplikacije potrebo je imati instaliran JRE (Java Runtime Environment) verzije 8 koji je moguće preuzeti sa sljedećeg linka https://www.oracle.com/technetwork/java/javase/downloads/jre8-downloads-2133155.html.

U direktoriju genomes nalaze se već naučeni automatski igrači. Za ispravan rad aplikacije nemojte brisati taj direktorij i uvijek ga držite u istom direktoriju iz kojeg pokrećete aplikaciju.